

# Scenario 1: the colored couple

2 players minimal
3 players + narrator maximal
1 Dice (D6)

## Setup

Place a 'Mainframe'-card in the ARPA-slot. Equip it with the PC-pins
Place Alice on 'pc1' and Bob on 'pc2'.

Place collegue-tokens (generic tokens) on all other PC's and on the 'administrator'-spot of the mainframe.

## Story 1.1

_Two players; one can manage the mainframe_

The year is 1972. The internet is starting to take hold, thanks to experiments and funding through the [ARPANET program](https://en.wikipedia.org/wiki/ARPANET).

[Ray Tomlinson](https://en.wikipedia.org/wiki/Ray_Tomlinson) invented _email_ a year earlier. He wrote a program that could deliver text messages from one computer to another, through the network-switched mainframes.

Alice is a black woman, Bob is a white man. They both work for ARPANET and something beautiful could blossom between them.

However, racism is rampant in the US of this time, with the racial segragation being abandonded only a few years earlier....

### Alice 1.1 

_Player character; available programs: Email_


You are a woman of colour and you have fallen in love with Bob. He works in a different department, but you'd like to tell him your feelings.
The best way to reach him is through this new email-program.

Execute the email program on your computer; send a sweet message to Bob to ask him on a date.

After sending the email, you eagerly await a response.

If the date is confirmed, Alice WINS a point in this scenario. Place this card onto your victory pile.
If the date is denied, Alice does not win a point. Place your card onto the discard pile.
If no response comes within 5 turns, you and Bob lose the scenario and discard both cards.


### Bob 1.1

_player character; available programs: Email_

You are a hard-working engineer. You don't do anything the first turn.

When you receive an email, send an appropriate answer with the 'email'-program. It is up to you to accept or deny the request in the email!

If Alice receives your email, you WIN this scenario.


### Collegues 1.1, 1.2

_The 'collegues' are placed into the game, but are not played by a player. Their actions are completely determined by the following rules._ 

_A collegue can send and receive emails_

_If a work-related email ends up with a bigot, then the bigot will send an email back to the sender which "thanks for the information" or something like that._

_If a collegue token is placed in the administrator position, it will *not* monitor emails actively. However, emails delivered to him (such as malformed emails) will be dealt with as written below._

_If a love-letter email ends up with a black pawn, unfold this and follow the instructions:_


- Roll a (six-sided)-dice. Run the following depending on the roll:

1, 2, or 3: the email arrived with a total bigot. They made a ton of drama around this love affair and both Alice and Bob lose their jobs. The Alice and Bob -points are both granted to Eve or are discarded if Eve is not yet in play.
4 or 5: This bigot complains to the higher ups about 'unprofessional messaging on the company network'. Both Alice and Bob get a warning. The cards for Alice and Bob both go to the discard pile. If Eve is in play, she wins the scenario and the player gets that point.
6. It's Alice's and Bobs lucky day! This person is very open-minded and in a mixed-race marriage as well. They congratulate you on the love and _forward_ the email to the intended recipient by running the forward-email-program. Continue the scenario.





### Story 1.2

Alice and Bob, a mixed couple, went on a date after all.
However, Eve (who also works at Arpanet) is a total bigot and saw them. Eve is trying to sabotage them...

## Setup

Remove the black pawn at PC3. Replace it with the Eve token.

Note: for two players: Alice and Bob can be played by one player, and Eve by a second player.

## Alice 1.2

_player character; available programs: Email; Phone_

Send an email the _fourth_ turn. This email is to bob and contains a love letter.
React on incoming emails.
You have a phone available to call everyone in your department. Using the phone takes one turn.

## Bob 1.2

_player character OR non-player-character to be run by Eve if not enough players; available programs: Email; Phone_

Send out a work-related email on the first turn to 'charlie@pc4'.

Wait for emails. 
If you receive a love letter from Alice within 6 turns, Alice and Bob WIN this scenario and can each keep their card. Eve must discard her card.
If no love letter arrives at turn six, this scenario ends NEUTRAL and the cards for Alice and Bob are discarded.


## Eve

_player character; available programs: email; Phone_

Your goal is to sabotage the love between Alice & Bob. Ideally, someone causes a lot of drama and get them fired...
This will make Alice en Bob LOSE the scenario. Getting a message with a bigot might result in this scenario.
Even better is to obtain a copy of a love letter _yourself_ as, you can cause the drama then...

Possible actions by Eve (pick one):

#### hijack

Try to become mainframe administrator:

  Roll a dice.
  If you roll 4 or more, place your EVE-pawn at the administrator-spot. You are now the administrator and will _actively_ monitor all emails. You can thus intercept emails from Alice and Bob! Wait for a love letter and cause drama. When this happens, Alice and Bob LOSE this scenario. Eve receives both the 'Alice' and 'Bob' points, and discards her own card.
  If you roll 3 or less, place a bigot in the administrator slot. (You can try to distract Alice when she sends her love letter in the third turn, e.g. by calling her). If the email is malformed (e.g. forgotten 'from', wrong email address, ...) the email might end up with a bigot. This gives a good chance that Alice & Bob lose or end Neutral.
  
 When the scenario is over, place card 'Eve' onto the discard pile 
  
#### Forging a fake email

 Send a fake email to Alice, telling her that the email address of Bob now is "bob@pc3" instead of "bob@pc2".
 If Alice falls for this, you'll soon obtain the love letter she sends and you can cause drama, resulting in Alice & Bob LOSING the scenario.
 This boldness is awarded by getting the victory point of both Alice, Bob _and_ Eve.
However, if Alice calls Bob to verify this and discovers the fraud, this will cause Eve to be fired! Alice will gain her victory point _and_ the victory point of Eve.


#### The third option (advanced)

 _only play this if you are familiar with the game_

 There is a way to play so that the email might not reach Bob by sending a single email.
 Can you figure out how? Hint: read the public side of the bigot-card.
 If this happens, Alice and Bob discard their cards; Eve keeps her victory point.


## Scenario 1: debriefing

Scenario 1 shows a simple but typical setup, with two common attack vectors:

- Administrators and intermediate machines can read (unencrypted) communication
- It is difficult to trust electronic communication. Sometimes, out-of-band verification must be done to make sure that we are communicating with who we think we are communicating with. This must _always_ be done via a different means of communication!
- For the advanced scenario of Eve: try to make the mainframe overloaded with emails. If only you could somehow multiply email traffic... 	

At last, there is always the possibility of human error - in this case by accidentaly misdelivering an email. What happens then is up to luck.
